declare module '@tomickigrzegorz/react-circular-progress-bar';
