declare module '*.png';
declare module '*.gif';
